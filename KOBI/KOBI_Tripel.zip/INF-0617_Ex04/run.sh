#!/bin/bash
WORK_FOLDER=/tmp/data/INF-0617_Ex04
INPUT_FOLDER=/tmp/data/books/txt_tst
OUT_FOLDER=$WORK_FOLDER/output
INPUT_INDEX=/tmp/data/books/master_list.csv

rm -rf $OUT_FOLDER

$HADOOP_HOME/bin/hadoop  jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-3.0.0.jar \
-input $INPUT_FOLDER/ \
-output $OUT_FOLDER/out1 \
-mapper "python $WORK_FOLDER/map.py $INPUT_INDEX" \
-reducer "python $WORK_FOLDER/reducer.py"

head -n 1 $OUT_FOLDER/out1/part-00000  | tr "," "\n" >$OUT_FOLDER/words.txt
mkdir $OUT_FOLDER/in2
tail -n +2 $OUT_FOLDER/out1/part-00000 >$OUT_FOLDER/in2/authors.txt

$HADOOP_HOME/bin/hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-3.0.0.jar \
-input $OUT_FOLDER/in2/ \
-output $OUT_FOLDER/out2 \
-mapper "python $WORK_FOLDER/map_2.py $OUT_FOLDER/words.txt" \
-reducer "python $WORK_FOLDER/reducer_2.py"

cat $OUT_FOLDER/out2/*