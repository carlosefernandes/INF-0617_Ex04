import sys
import operator

word_count = {}
author_words = {}
words = set()

for line in sys.stdin:
    author, word, count = line.split(',')
    count=int(count)

    if author not in author_words.keys():
            author_words[author]=set()
    author_words[author].add(word)
    if word not in word_count:
        word_count[word] = count
    else:
        word_count[word] += count
sorted_counts = sorted(word_count.items(),key = operator.itemgetter(1),reverse = True)
words_out=""
count=0
for word in sorted_counts:
    count+=1
    words_out = words_out + word[0] + ","
    if count==3000: break
print(words_out)
for i in author_words.keys():
    author=i
    for word in author_words[i]:
        author = author + "," + word
    print(author)

#print()
#     count = int(count)
#     if word not in counts :
#         counts[word] = count
#     else :
#         counts[word] = counts[word] + count

# sorted_counts = sorted(counts.items(),key = operator.itemgetter(1),reverse = True)

# lines_counter = 0

# for line in sorted_counts :
#     if (lines_counter < 3000):
#         print(line[0])
#         lines_counter = lines_counter + 1
#     else:
#         break;
