import sys
import re
import os
import csv

book_authors = {}
with open(sys.argv[1]) as csv_file:
	csv_reader = csv.reader(csv_file)
	# skip header lines
	for i in range(5):
		next(csv_reader)
	# process in line
	for row in csv_reader:
		book_authors[row[4]] = row[3].lower()

for line in sys.stdin:
	file = os.environ['mapreduce_map_input_file']
	prefix, file = file.split("u-")
	author=book_authors[file]
	line = re.sub('[^a-z]', ' ', line.lower())
	for word in line.split() :
		print(author + "," + word + "," + str(1))
